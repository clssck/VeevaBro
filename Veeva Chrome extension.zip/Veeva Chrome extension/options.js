document.addEventListener("DOMContentLoaded", function () {
  const saveButton = document.getElementById("saveButton");
  const testButton = document.getElementById("testButton");
  const statusDiv = document.getElementById("status");
  const vaultUrlInput = document.getElementById("vaultUrl");
  const apiVersionInput = document.getElementById("apiVersion");
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  const sessionIdContainer = document.getElementById("sessionIdContainer");
  const sessionIndicator = document.getElementById("sessionIndicator");

  // Load saved settings
  chrome.storage.sync.get(
    ["vaultUrl", "apiVersion", "username", "password", "sessionId"],
    function (items) {
      if (items.vaultUrl) {
        vaultUrlInput.value = items.vaultUrl;
      }
      if (items.apiVersion) {
        apiVersionInput.value = items.apiVersion;
      }
      if (items.username) {
        usernameInput.value = items.username;
      }
      if (items.password) {
        passwordInput.value = items.password;
      }
      if (items.sessionId) {
        sessionIdContainer.style.display = "block";
        sessionIndicator.classList.remove("indicator-red");
        sessionIndicator.classList.add("indicator-green");
      } else {
        sessionIdContainer.style.display = "block";
        sessionIndicator.classList.remove("indicator-green");
        sessionIndicator.classList.add("indicator-red");
      }
    }
  );

  saveButton.addEventListener("click", function () {
    const vaultUrl = vaultUrlInput.value;
    const apiVersion = apiVersionInput.value;
    const username = usernameInput.value;
    const password = passwordInput.value;

    if (!vaultUrl || !apiVersion || !username || !password) {
      updateStatus("Error: All fields are required", true);
      return;
    }

    chrome.storage.sync.set(
      { vaultUrl, apiVersion, username, password },
      function () {
        updateStatus("Settings saved successfully", false);
      }
    );
  });

  testButton.addEventListener("click", function () {
    const vaultUrl = vaultUrlInput.value;
    const apiVersion = apiVersionInput.value;
    const username = usernameInput.value;
    const password = passwordInput.value;

    if (!vaultUrl || !apiVersion || !username || !password) {
      updateStatus("Error: All fields are required", true);
      return;
    }

    // Ensure the URL starts with https://
    let formattedVaultUrl = vaultUrl.trim();
    if (!formattedVaultUrl.startsWith("https://")) {
      formattedVaultUrl = "https://" + formattedVaultUrl;
    }

    updateStatus("Testing connection...", false);

    // Send a message to the background script to test the connection
    chrome.runtime.sendMessage(
      {
        action: "authenticate",
        config: { vaultUrl: formattedVaultUrl, apiVersion, username, password },
      },
      function (response) {
        if (chrome.runtime.lastError) {
          updateStatus("Error: " + chrome.runtime.lastError.message, true);
          return;
        }

        if (response.success) {
          updateStatus(
            "Connection successful! Session ID: " + response.sessionId,
            false
          );
          sessionIndicator.classList.remove("indicator-red");
          sessionIndicator.classList.add("indicator-green");
          chrome.storage.sync.set({ sessionId: response.sessionId });
        } else {
          updateStatus(
            "Connection failed: " + (response.error || "Unknown error"),
            true
          );
          sessionIndicator.classList.remove("indicator-green");
          sessionIndicator.classList.add("indicator-red");
          chrome.storage.sync.remove("sessionId");
        }
      }
    );
  });

  function updateStatus(message, isError) {
    statusDiv.textContent = message;
    statusDiv.className = isError ? "error" : "success";
  }
});
